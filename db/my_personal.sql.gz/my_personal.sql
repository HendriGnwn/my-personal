-- Adminer 4.2.2 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `bio_profile`;
CREATE TABLE `bio_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `metakey` varchar(300) NOT NULL,
  `metakey_en` varchar(300) NOT NULL,
  `metadesc` text NOT NULL,
  `metadesc_en` text NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(300) NOT NULL,
  `latitude` varchar(20) NOT NULL,
  `longitude` varchar(20) NOT NULL,
  `bio` varchar(500) NOT NULL,
  `website` varchar(100) NOT NULL,
  `skype` varchar(70) NOT NULL,
  `facebook` varchar(70) NOT NULL,
  `twitter` varchar(70) NOT NULL,
  `dribbble` varchar(70) NOT NULL,
  `instagram` varchar(70) NOT NULL,
  `linked_in` varchar(70) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `creaated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `carousel`;
CREATE TABLE `carousel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `short_description` varchar(200) NOT NULL,
  `picture` varchar(150) NOT NULL,
  `url` varchar(100) NOT NULL,
  `order` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `carousel` (`id`, `name`, `short_description`, `picture`, `url`, `order`, `status`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(5,	'Home',	'This Home',	'home-790d1ec7051c353dd518b52506e8561c.jpg',	'#home',	0,	1,	'2016-07-01 14:22:59',	1,	NULL,	1);

DROP TABLE IF EXISTS `client`;
CREATE TABLE `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `date` date NOT NULL,
  `picture` varchar(150) NOT NULL,
  `url` varchar(200) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `client` (`id`, `name`, `description`, `date`, `picture`, `url`, `status`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1,	'uhe difbsnf',	'qweoiqjwe ',	'2016-07-15',	'uhe-difbsnf-5670b7faaff2e8059512bb78dc878e81.jpg',	'www.goldenrama.com',	1,	'2016-07-01 14:30:39',	1,	'2016-07-01 14:33:16',	1);

DROP TABLE IF EXISTS `contact`;
CREATE TABLE `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `contact` (`id`, `name`, `email`, `message`, `status`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1,	'qwe',	'qwe@gmal.com',	'qwe',	1,	'2016-07-01 14:37:17',	1,	NULL,	1),
(2,	'123',	'123@gmail.com',	'qweqeqwe',	5,	'2016-07-01 14:39:07',	1,	NULL,	1),
(4,	'qwe',	'qwe@gasd.s',	'asd',	0,	'2016-07-01 15:26:36',	1,	NULL,	1),
(5,	'13',	'123@sad.sd',	'asd',	5,	'2016-07-01 15:28:37',	1,	NULL,	1);

DROP TABLE IF EXISTS `education`;
CREATE TABLE `education` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `url` varchar(150) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `education_status` int(11) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `education` (`id`, `name`, `description`, `url`, `start_date`, `end_date`, `education_status`, `status`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1,	'qwe',	'qweqweqwe',	'qweqwe',	'2016-07-04',	NULL,	1,	1,	'2016-07-01 15:28:53',	1,	'2016-07-01 15:29:42',	1),
(2,	'qwe',	'qwe',	'qwe',	'2016-07-20',	NULL,	1,	1,	'2016-07-01 15:29:14',	1,	NULL,	1);

DROP TABLE IF EXISTS `employement`;
CREATE TABLE `employement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `url` varchar(150) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `employement_status` int(11) NOT NULL DEFAULT '1',
  `status` int(11) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `employement` (`id`, `name`, `description`, `url`, `start_date`, `end_date`, `employement_status`, `status`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1,	'sad',	'asd',	'asd',	'2016-07-20',	'2016-07-27',	0,	1,	'2016-07-01 15:40:54',	1,	NULL,	1);

DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `url` varchar(100) NOT NULL,
  `category` char(20) NOT NULL,
  `order` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `menu_child`;
CREATE TABLE `menu_child` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `url` varchar(100) NOT NULL,
  `order` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `portfolio`;
CREATE TABLE `portfolio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `url` varchar(150) NOT NULL,
  `date` date NOT NULL,
  `picture` varchar(200) NOT NULL,
  `client_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `portfolio` (`id`, `name`, `description`, `url`, `date`, `picture`, `client_id`, `status`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1,	'123',	'123',	'123123',	'2016-07-20',	'123-134563af8a9f8cba29f5657bba7435dc.png',	1,	1,	'2016-07-01 16:05:39',	1,	NULL,	1),
(2,	'asd',	'asd',	'asd',	'2016-07-20',	'asd-09ab2a9f6ad486eb0ef423939bc17ec6.png',	1,	1,	'2016-07-01 16:49:11',	1,	'2016-07-01 16:50:10',	1),
(3,	'21',	'3123',	'213',	'2016-07-19',	'21-2d41aa6cfd6f3eadcaa29169ed322202.png',	1,	1,	'2016-07-01 16:50:30',	1,	NULL,	1),
(4,	'qwe',	'qwe',	'qwe',	'2016-07-26',	'qwe-e58828318b41caa4bbe344298ed62c4c.jpg',	1,	1,	'2016-07-01 16:51:18',	1,	NULL,	1),
(5,	'qwe',	'qwe',	'qwe',	'2016-07-13',	'qwe-e5459542043aa78bfc2c5d1d3504d6ba.png',	1,	1,	'2016-07-01 16:52:01',	1,	'2016-07-01 17:02:30',	1),
(6,	'asd',	'asd',	'asdasd',	'2016-07-12',	'asd-8818f7682dfd5cbd0cc414b989d87c1f.jpg',	1,	1,	'2016-07-01 17:03:02',	1,	NULL,	1),
(7,	'asd',	'asd',	'asd',	'2016-07-13',	'asd-730babf6b37329e500551c64494acafb.png',	1,	1,	'2016-07-01 17:04:09',	1,	NULL,	1),
(8,	'123',	'123',	'123',	'2016-07-19',	'123-5db1dcd2e926774f18ee05aa25cbc2c2.jpg',	1,	1,	'2016-07-01 17:05:18',	1,	NULL,	1),
(9,	'asd',	'asd',	'asd',	'2016-07-21',	'asd-6b9a5981f98b78739173334a29c54fdd.jpg',	1,	1,	'2016-07-01 17:05:49',	1,	NULL,	1),
(10,	'asd',	'asdasd',	'asdasd',	'2016-07-19',	'asd-5faab0edcc792e580290cbc515cf9fc1.jpg',	1,	1,	'2016-07-01 17:06:24',	1,	NULL,	1),
(11,	'asd',	'asd',	'asd',	'2016-07-19',	'asd-3a2f1f5e9bc213292c1d6d1921d8e652.jpg',	1,	1,	'2016-07-01 17:07:18',	1,	NULL,	1),
(12,	'asd',	'asd',	'asd',	'2016-07-20',	'asd-1c5453a8c67ee07020e8cf38e11485f3.png',	1,	1,	'2016-07-01 17:09:21',	1,	NULL,	1),
(13,	'asd',	'asd',	'asd',	'2016-07-20',	'asd-764cb5e3e61d87a6f38b929fb2e5c22f.png',	1,	1,	'2016-07-01 17:09:41',	1,	NULL,	1),
(14,	'asd',	'asd',	'asd',	'2016-07-20',	'asd-1a2425cc1ca1366fc6843e8556950cb8.png',	1,	1,	'2016-07-01 17:10:02',	1,	'2016-07-01 17:14:05',	1);

DROP TABLE IF EXISTS `portfolio_has_tag`;
CREATE TABLE `portfolio_has_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `portfolio_id` int(11) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `portfolio_has_tag` (`id`, `portfolio_id`, `tag_id`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1,	2,	NULL,	'2016-07-01 16:49:12',	1,	NULL,	1),
(2,	2,	NULL,	'2016-07-01 16:49:12',	1,	NULL,	1),
(3,	2,	NULL,	'2016-07-01 16:49:12',	1,	NULL,	1),
(14,	14,	1,	'2016-07-01 17:14:05',	1,	NULL,	1),
(15,	14,	2,	'2016-07-01 17:14:05',	1,	NULL,	1);

DROP TABLE IF EXISTS `service`;
CREATE TABLE `service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `service` (`id`, `name`, `description`, `slug`, `icon`, `status`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1,	'qwe',	'qwe',	'qwe',	'icon-qwe-467e33d03d61611ae07c5fe4884ae890.gif',	1,	'2016-07-01 16:23:52',	1,	NULL,	1);

DROP TABLE IF EXISTS `skill`;
CREATE TABLE `skill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `statistic` int(11) NOT NULL DEFAULT '50',
  `status` int(11) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `skill` (`id`, `name`, `statistic`, `status`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1,	'tes',	23,	1,	'2016-07-01 15:52:18',	1,	NULL,	1);

DROP TABLE IF EXISTS `tag`;
CREATE TABLE `tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `icon` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tag` (`id`, `name`, `description`, `icon`, `slug`, `status`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1,	'PHP',	'asdasd',	'',	'php',	1,	'2016-07-01 16:48:27',	1,	NULL,	1),
(2,	'Yii Framework',	'',	'',	'yii-framework',	1,	'2016-07-01 16:48:35',	1,	NULL,	1),
(3,	'CodeIgniter',	'',	'',	'codeigniter',	1,	'2016-07-01 16:48:43',	1,	NULL,	1);

DROP TABLE IF EXISTS `testimonial`;
CREATE TABLE `testimonial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `company` varchar(100) NOT NULL,
  `description` text,
  `date` date NOT NULL,
  `picture` varchar(150) NOT NULL,
  `url` varchar(200) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `password_reset_token` (`password_reset_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `status`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1,	'admin',	'qxJqCproLEHKP3hDGBuEUzD1RyM8CHkT',	'$2y$13$QyUblB.2cgvhk/ojZcGmeevWdRSGizsr7Nhkgs5hTc1OYByI3iHCq',	NULL,	'admin@admin.com',	1,	'2016-06-27 17:06:07',	1,	'2016-06-29 13:46:20',	1),
(2,	'hendrigunawan',	'XwK3Ut7cwyCklw_fLvquYjpxbAElJivd',	'$2y$13$f68WGf5uSpyQHtj7BcllXe/qKfCLghRNGemIkkcnBJluKxeJ7HhVu',	NULL,	'hendri.gunawan@computesta.com',	1,	'2016-06-27 17:06:07',	1,	NULL,	NULL);

-- 2016-07-01 10:23:46
